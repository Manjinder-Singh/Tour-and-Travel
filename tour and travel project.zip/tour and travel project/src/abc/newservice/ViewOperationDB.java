/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package abc.newservice;

//import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
//import java.util.List;

/**
 *
 * @author Administrator
 */
public class ViewOperationDB {
      DB db;
  public ViewOperationDB()
   {
        db=ConnectionDB.ConDB();
        
    
}
  public DBCursor searchAddinfo(String city)
     {
   DBCollection table =db.getCollection("addinfo");
 BasicDBObject Searchquery=new BasicDBObject();
 Searchquery.put("City",city);
 //Searchquery.put("city",city );
 //Searchquery.put("famousplaces", famousplaces);
 //BasicDBList List=new BasicDBList();
//List.add(Searchquery);
 //BasicDBObject search=new BasicDBObject();
 //search.put("&and",List);
 DBCursor cursor= table.find(Searchquery);
 return cursor;
 }}


