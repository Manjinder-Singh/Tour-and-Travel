/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package abc.newservice;

import abc.newservice.template.UserWisetemplate;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;

/**
 *
 * @author Administrator
 */
public class User1OperationDB {
    DB db;
    public User1OperationDB()
    {
        db=ConnectionDB.ConDB();
    }
    public void User1OperationSave(UserWisetemplate t )
    {
                DBCollection table=db.getCollection("xyz");
                BasicDBObject document=new BasicDBObject();
                
                //document.put("UserFirstname",t.getUserfirstname());
                //document.put("gender",t.getGender());
                //document.put("age",t.getAge());
                //document.put("dob",t.getDob());
                //document.put("husbandname",t.getHusbandname());
                //document.put("fathername",t.getFathername());
                //document.put("emailid",t.getEmailid());
                //document.put("userlastname",t.getUserlastname());
                //document.put("mobile",t.getMobile());
                //document.put("landline",t.getLandline());
                //document.put("pincode",t.getPincode());
               // document.put("country",t.getCountry());
                //document.put("state",t.getState());
                document.put("Username",t.getUserName());
                document.put("gender",t.getGender());
                document.put("age",t.getAge());
                document.put("contactno",t.getContactno());
                //document.put("FromLocation",t.getFromlocation());
                //document.put("ToLocation",t.getTolocation());
                document.put("emailid",t.getEmailid());
                //document.put("year",t.getYear());
                 table.insert(document);
    }
    
}

    
    

