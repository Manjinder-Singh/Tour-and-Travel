/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package abc.newservice.template;

/**
 *
 * @author Administrator
 */
public class MonthWisetemplate {
    String Month,Packageid,Packagename,Modeofpayment;

    public String getModeofpayment() {
        return Modeofpayment;
    }

    public void setModeofpayment(String Modeofpayment) {
        this.Modeofpayment = Modeofpayment;
    }

    public String getMonth() {
        return Month;
    }

    public void setMonth(String Month) {
        this.Month = Month;
    }

    public String getPackageid() {
        return Packageid;
    }

    public void setPackageid(String Packageid) {
        this.Packageid = Packageid;
    }

    public String getPackagename() {
        return Packagename;
    }

    public void setPackagename(String Packagename) {
        this.Packagename = Packagename;
    }
    
}
