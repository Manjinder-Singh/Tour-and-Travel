/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package abc.newservice.template;

/**
 *
 * @author Administrator
 */
public class YearWisetemplate {
    String Packageid,Packagename,days,nights,fromlocation,tolocation,modeofpayment;
    int year;

    public String getPackageid() {
        return Packageid;
    }

    public void setPackageid(String Packageid) {
        this.Packageid = Packageid;
    }

    public String getPackagename() {
        return Packagename;
    }

    public void setPackagename(String Packagename) {
        this.Packagename = Packagename;
    }

    public String getDays() {
        return days;
    }

    public void setDays(String days) {
        this.days = days;
    }

    public String getFromlocation() {
        return fromlocation;
    }

    public void setFromlocation(String fromlocation) {
        this.fromlocation = fromlocation;
    }

    public String getModeofpayment() {
        return modeofpayment;
    }

    public void setModeofpayment(String modeofpayment) {
        this.modeofpayment = modeofpayment;
    }

    public String getNights() {
        return nights;
    }

    public void setNights(String nights) {
        this.nights = nights;
    }

    public String getTolocation() {
        return tolocation;
    }

    public void setTolocation(String tolocation) {
        this.tolocation = tolocation;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
}
