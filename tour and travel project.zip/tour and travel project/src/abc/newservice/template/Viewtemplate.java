/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package abc.newservice.template;

/**
 *
 * @author Administrator
 */
public class Viewtemplate {
    String cityname,famousplaces,travelcountryid,Hotelname,vehiclefacility;

    public String getHotelname() {
        return Hotelname;
    }

    public void setHotelname(String Hotelname) {
        this.Hotelname = Hotelname;
    }

    public int getHotelpackage() {
        return hotelpackage;
    }

    public void setHotelpackage(int hotelpackage) {
        this.hotelpackage = hotelpackage;
    }

    public String getVehiclefacility() {
        return vehiclefacility;
    }

    public void setVehiclefacility(String vehiclefacility) {
        this.vehiclefacility = vehiclefacility;
    }
    int hotelpackage;

    public String getTravelcountryid() {
        return travelcountryid;
    }

    public void setTravelcountryid(String travelcountryid) {
        this.travelcountryid = travelcountryid;
    }
    

    public String getCityname() {
        return cityname;
    }

    public void setCityname(String cityname) {
        this.cityname = cityname;
    }

    public String getFamousplaces() {
        return famousplaces;
    }

    public void setFamousplaces(String famousplaces) {
        this.famousplaces = famousplaces;
    }

   
    
    
}
