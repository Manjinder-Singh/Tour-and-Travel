/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package abc.newservice.template;

import javax.swing.JRadioButton;



    

/**
 *
 * @author Administrator
 */
public class abctemplate {
    String City,travelcountry,Vehiclefacility,Fromlocation,Tolocation,Hotelname,Hoteladdress,duration,hotelcontactno,days,nights,username,Password,userfirstname,userlastname,gender,dob,husbandname,fathername,country,state,emailid,packagename,modesofpayment,natureoftravel,travelagent,Packageid,Famousplaces,month;
    int date,year;

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getDate() {
        return date;
    }

    public void setDate(int date) {
        this.date = date;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getFamousplaces() {
        return Famousplaces;
    }

    public void setFamousplaces(String Famousplaces) {
        this.Famousplaces = Famousplaces;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String City) {
        this.City = City;
    }

    public String getFromlocation() {
        return Fromlocation;
    }

    public void setFromlocation(String Fromlocation) {
        this.Fromlocation = Fromlocation;
    }

    public String getHoteladdress() {
        return Hoteladdress;
    }

    public void setHoteladdress(String Hoteladdress) {
        this.Hoteladdress = Hoteladdress;
    }

    public String getHotelname() {
        return Hotelname;
    }

    public void setHotelname(String Hotelname) {
        this.Hotelname = Hotelname;
    }

    public String getTolocation() {
        return Tolocation;
    }

    public void setTolocation(String Tolocation) {
        this.Tolocation = Tolocation;
    }

    public String getVehiclefacility() {
        return Vehiclefacility;
    }

    public void setVehiclefacility(String Vehiclefacility) {
        this.Vehiclefacility = Vehiclefacility;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public int getHotelpackage() {
        return hotelpackage;
    }

    public void setHotelpackage(int hotelpackage) {
        this.hotelpackage = hotelpackage;
    }

    public String getModesofpayment() {
        return modesofpayment;
    }

    public void setModesofpayment(String modesofpayment) {
        this.modesofpayment = modesofpayment;
    }

    public int getNoofpeople() {
        return noofpeople;
    }

    public void setNoofpeople(int noofpeople) {
        this.noofpeople = noofpeople;
    }

    public int getNoofseats() {
        return noofseats;
    }

    public void setNoofseats(int noofseats) {
        this.noofseats = noofseats;
    }

    public String getPackageid() {
        return Packageid;
    }

    public void setPackageid(String Packageid) {
        this.Packageid = Packageid;
    }

    public int getAddress() {
        return address;
    }

    public void setAddress(int address) {
        this.address = address;
    }

    public int getContactno() {
        return contactno;
    }

    public void setContactno(int contactno) {
        this.contactno = contactno;
    }

    public int getForeignmobileno() {
        return foreignmobileno;
    }

    public void setForeignmobileno(int foreignmobileno) {
        this.foreignmobileno = foreignmobileno;
    }

    public String getNatureoftravel() {
        return natureoftravel;
    }

    public void setNatureoftravel(String natureoftravel) {
        this.natureoftravel = natureoftravel;
    }

    public String getTravelagent() {
        return travelagent;
    }

    public void setTravelagent(String travelagent) {
        this.travelagent = travelagent;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getEmailid() {
        return emailid;
    }

    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }

    public String getFathername() {
        return fathername;
    }

    public void setFathername(String fathername) {
        this.fathername = fathername;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getHusbandname() {
        return husbandname;
    }

    public void setHusbandname(String husbandname) {
        this.husbandname = husbandname;
    }

    public int getLandline() {
        return landline;
    }

    public void setLandline(int landline) {
        this.landline = landline;
    }

    public int getMobile() {
        return mobile;
    }

    public void setMobile(int mobile) {
        this.mobile = mobile;
    }

    public int getPincode() {
        return pincode;
    }

    public void setPincode(int pincode) {
        this.pincode = pincode;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getUserfirstname() {
        return userfirstname;
    }

    public void setUserfirstname(String userfirstname) {
        this.userfirstname = userfirstname;
    }

    public String getUserlastname() {
        return userlastname;
    }

    public void setUserlastname(String userlastname) {
        this.userlastname = userlastname;
    }

    
    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDays() {
        return days;
    }

    public void setDays(String days) {
        this.days = days;
    }

    public String getNights() {
        return nights;
    }

    public void setNights(String nights) {
        this.nights = nights;
    }

    

    

   

    public String getHotelcontactno() {
        return hotelcontactno;
    }

    public void setHotelcontactno(String hotelcontactno) {
        this.hotelcontactno = hotelcontactno;
    }
     int noofseats,route,hotelpackage,noofpeople,age,mobile,landline,pincode,contactno,foreignmobileno,address;
     String userid;

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

   
    public String getPackagename() {
        return packagename;
    }

    public void setPackagename(String packagename) {
        this.packagename = packagename;
    }

    public int getRoute() {
        return route;
    }

    public void setRoute(int route) {
        this.route = route;
    }

    public String getTravelcountry() {
        return travelcountry;
    }

    public void setTravelcountry(String travelcountry) {
        this.travelcountry = travelcountry;
    }

    }
    

    

   
    
