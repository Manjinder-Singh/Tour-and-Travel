/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package abc.newservice;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.Cursor;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.client.MongoCursor;

/**
 *
 * @author Administrator
 */
public class AlloperationDB {
    DB db;
  public AlloperationDB()
   {
        db=ConnectionDB.ConDB();
        
   }
  
public DBCursor searchUser(String Userid)
     {
 DBCollection table =db.getCollection("payment");
 BasicDBObject Searchquery=new BasicDBObject();
 Searchquery.put("userid",Userid);
 //BasicDBList list=new BasicDBList();
 //list.add(Searchquery);
 //BasicDBObject search= new BasicDBObject();
 //search.put("$and", Searchquery);
  DBCursor cursor= table.find(Searchquery);
 return cursor;
 }}
