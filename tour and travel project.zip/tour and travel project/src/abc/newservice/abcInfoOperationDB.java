/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package abc.newservice;

import abc.newservice.template.abctemplate;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;

/**
 *
 * @author Administrator
 */
public class abcInfoOperationDB {
    DB db;
    public abcInfoOperationDB()
    {
        db=ConnectionDB.ConDB();
    }
    public void abcInfoSave( abctemplate t )
            {
                DBCollection table=db.getCollection("addinfo");
                BasicDBObject document=new BasicDBObject();
                document.put("FamousPlaces",t.getFamousplaces());
                document.put("travelcountry",t.getTravelcountry() );
                document.put("City",t.getCity());
                document.put("duration",t.getDuration());
                document.put("vehiclefacility",t.getVehiclefacility());
                document.put("noofseats", t.getNoofseats());
                document.put("days",t.getDays());
                document.put("fromlocation", t.getFromlocation());
                document.put("route",t.getRoute());
                document.put("hotel name", t.getHotelname());
                document.put("hotelcontact", t.getHotelcontactno());
                document.put("hoteladdress",t.getHoteladdress());
                document.put("hotelpackage", t.getHotelpackage());
                document.put("noofpeople",t.getNoofpeople());
                document.put("nights",t.getNights());
                document.put("tolocation",t.getTolocation());
              table.insert(document);
        
    }
    
    
}
