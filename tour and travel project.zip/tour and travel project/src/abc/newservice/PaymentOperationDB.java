/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package abc.newservice;

import abc.newservice.template.abctemplate;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;

/**
 *
 * @author Administrator
 */
public class PaymentOperationDB {
    DB db;
    public PaymentOperationDB()
    {
        db=ConnectionDB.ConDB();
    }
    public void PaymentOperationSave(abctemplate t )
    {
        DBCollection table=db.getCollection("payment");
                BasicDBObject document=new BasicDBObject();
                document.put("userid", t.getUserid());
                document.put("Packageid",t.getPackageid());
                document.put("packagename", t.getPackagename());
                document.put("days",t.getDays());
                document.put("fromlocation", t.getFromlocation());
                document.put("route",t.getRoute());
                document.put("nights",t.getNights());
                document.put("tolocation",t.getTolocation());
                document.put("modesofpayments",t.getModesofpayment());
                document.put("date", t.getDate());
                document.put("month",t.getMonth());
                document.put("year", t.getYear());
                table.insert(document);
    
}}
