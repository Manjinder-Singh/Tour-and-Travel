/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package abc.newservice;

import com.mongodb.DB;

/**
 *
 * @author Administrator
 */
class abcDBObject {
    DB db;
    
}
