/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package abc.newservice;

import com.mongodb.DB;
import com.mongodb.MongoClient;

/**
 *
 * @author Administrator
 */
public class ConnectionDB {
     public static DB ConDB()
     {
    MongoClient mongo =new MongoClient("localhost",27017);
     DB db =mongo.getDB("abc");
    return db;
     }
    
}
