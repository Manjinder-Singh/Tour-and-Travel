/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package abc.newservice;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;

/**
 *
 * @author Administrator
 */
public class MonthwiseOperationDB {
    DB db;
  public MonthwiseOperationDB()
   {
        db=ConnectionDB.ConDB();
        
    
}
  public DBCursor searchpayinfo(String id)
     {
   DBCollection table =db.getCollection("payment");
 BasicDBObject Searchquery=new BasicDBObject();
 Searchquery.put("userid",id);
 //Searchquery.put("city",city );
 //Searchquery.put("famousplaces", famousplaces);
 //BasicDBList List=new BasicDBList();
//List.add(Searchquery);
 //BasicDBObject search=new BasicDBObject();
 //search.put("&and",List);
 DBCursor cursor= table.find(Searchquery);
 return cursor;
 }
}

