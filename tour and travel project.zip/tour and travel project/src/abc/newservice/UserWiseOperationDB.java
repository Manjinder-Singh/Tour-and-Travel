/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package abc.newservice;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import org.bson.types.ObjectId;

/**
 *
 * @author Administrator
 */
public class UserWiseOperationDB  {
      DB db;
  public UserWiseOperationDB()
   {
        db=ConnectionDB.ConDB();
        
    
}
  public DBCursor searchUser()
     {
   DBCollection table =db.getCollection("xyz");
// BasicDBObject Searchquery=new BasicDBObject();
// Searchquery.put("_id",new ObjectId(id));
 //Searchquery.put("city",city );
 //Searchquery.put("famousplaces", famousplaces);
 //BasicDBList List=new BasicDBList();
//List.add(Searchquery);
 //BasicDBObject search=new BasicDBObject();
 //search.put("&and",List);
 DBCursor cursor= table.find();
 return cursor;
 }}
    
